<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Function with return value</title>
</head>
<body>
<h2>Writing PHP Function with return value</h2>
    <?php
    /* Defining a PHP Function*/
    function addFunction($num1, $num2){
            $sum = $num1 + $num2;
            return $sum;      
    }
    $return_value = addFunction(10, 20);

    echo "Return value from the Function : $return_value";
    ?>
</body>
</html>