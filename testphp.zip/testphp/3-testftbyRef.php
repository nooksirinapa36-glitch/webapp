<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Function with paramiters</title>
</head>
<body>
    <h2>PHP Function with paramiters</h2>
    <?php
    /* Defining a PHP addFive Function*/
    function addFive($num):void{
        $num += 5;
    }
    /* Defining a PHP addSix Function*/

    /* add & it means pass by reference*/
    function addSix(&$num):void{
        $num += 6;}

    /* Defining original number*/
    $originum = 10;
    addFive($originum);
    /* show result of addFive by reference*/
    echo "Original Value is $originum <br/>";
    addSix($originum);
    /* show result of addSix by reference*/
    echo "Original Value is $originum <br/>";
    ?>
</body>
</html>