<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercise1</title>
</head>
<body>
    <h2>Exercise1</h2>
    <?php
    function test($s){
        $last = substr($s, -1);
        return $last . $s .$last;
    }
    var_dump(test("RED"));
    var_dump(test("BLACK"));
    ?>
</body>
</html>