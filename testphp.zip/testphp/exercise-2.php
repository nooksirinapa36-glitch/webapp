<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercise2</title>
</head>
<body>
    <h2>Exercise2</h2>
    <?php
    function test($temp1,$temp2){
        return ($temp1 < 0 && $temp2 > 100) || ($temp1 > 100 && $temp2 < 0);
    }
    var_dump(test(120, -1)). "<br>";
    var_dump(test(-1, 120)). "<br>";
    var_dump(test(2, 120)). "<br>";
    ?>
</body>
</html>