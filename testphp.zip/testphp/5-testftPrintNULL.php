<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Writing PHP Function with return value</title>
</head>
<body>
<h2>Writing PHP Function with return value</h2>
    <?php
    /* Defining a PHP Function*/
    function PrintMe($param = NULL){
            print $param;    
    }
    PrintMe("This is Test");
    PrintMe();
    PrintMe("<br/>This is Test");
    PrintMe();
    PrintMe();
    ?>
</body>
</html>