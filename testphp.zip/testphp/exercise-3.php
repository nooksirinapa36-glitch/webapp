<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercise3</title>
</head>
<body>
    <h2>Exercise3</h2>
    <?php
 
 function test($x, $y) {
     $x_in_range = ($x >= 20 && $x <= 50);
     $y_in_range = ($y >= 20 && $y <= 50);
     return ($x_in_range && !$y_in_range) || ($y_in_range && !$x_in_range);
 }
  
  
 var_dump(test(20, 84));
 echo "</br>";
 var_dump(test(14, 50));
 echo "</br>";
 var_dump(test(11, 45));
 echo "</br>";
 var_dump(test(25, 40));
  
 ?>
  
</body>
</html>