console.log("Hello JavaScript");
console.log("Hello Computer Science");
document.getElementById("text").innerHTML= "this is first time for JavaScript";
document.writeln("Hello document write");
Window.alert("welcome to mr page")